
from bigchaindb import _app_config

app_config = {
    'server_port': _app_config['server_port'],
    'restore_server_port': _app_config['restore_server_port'],
    'service_name': _app_config['service_name'],
    'setup_name': _app_config['setup_name'],
}

