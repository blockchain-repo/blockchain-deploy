# Licenses

Information about how the BigchainDB Server code and documentation are licensed can be found in [the LICENSES.md file](https://github.com/bigchaindb/bigchaindb/blob/master/LICENSES.md) of the bigchaindb/bigchaindb repository on GitHub.
