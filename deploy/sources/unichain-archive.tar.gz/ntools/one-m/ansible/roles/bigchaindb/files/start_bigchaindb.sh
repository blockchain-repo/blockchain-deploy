#!/bin/bash
bigchaindb -y start &
disown
