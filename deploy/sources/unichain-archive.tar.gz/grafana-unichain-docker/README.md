# Grafana Docker image

This project builds a Docker image with the latest master build of Grafana, with custom BigchainDB dashboard. From [the official grafana-docker container](https://github.com/grafana/grafana-docker).
